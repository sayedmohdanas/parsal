import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import Colors from '../../../../common/Colors';
import { responsiveHeight } from '../../../../common/metrices';
import { Fonts, FontSizes } from '../../../../common/Theme';

const PartnerAddressCard = ({ profile }) => {

    return (
        <View style={styles.card}>
            <View style={styles.section}>
                <Text style={styles.label}>Home Address:</Text>
                <Text style={styles.data}>{profile?.address || 'N/A'}</Text>
            </View>
            <View style={styles.section}>
                <Text style={styles.label}>Mobile Number:</Text>
                <Text style={styles.data}>{profile?.phone || 'N/A'}</Text>
            </View>
        </View>
    );
};


const styles = StyleSheet.create({
    card: {
        backgroundColor: Colors.white,
        width: '100%',
        padding: 16,
        marginTop: responsiveHeight(12),
        backgroundColor: Colors.white
    },
    section: {
        marginBottom: responsiveHeight(12),
    },
    label: {
        fontWeight: Fonts.medium,
        fontSize: FontSizes.medium,
        marginBottom: responsiveHeight(4),
        color: Colors.grey
    },
    data: {
        
        fontSize: FontSizes.semiLarge,
        color: Colors.black
    },
});

export default PartnerAddressCard;
